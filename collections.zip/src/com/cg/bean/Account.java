package com.cg.bean;

public abstract class Account {
	

	private int accountId;
	private int mobileNo;
	private String accountHolderName;
	private double balance;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public Account(int accountId, int mobileNo, String accountHolderName, double balance) {
		super();
		this.accountId = accountId;
		this.mobileNo = mobileNo;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", mobileNo=" + mobileNo + ", accountHolderName=" + accountHolderName
				+ ", balance=" + balance + "]";
	}
	
}