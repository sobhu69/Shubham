package cg;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Collection2 {

	public static void main(String[] args) {
			List<String> col= new ArrayList<String>();
		
				col.add("Name1");
				col.add("Name2");
				col.add("Name3");
				col.add("Name4");
				col.add("Name2");
				System.out.println(col.size());
				System.out.println(col);
				System.out.println("-------------");
				
				for(String s: col) {
					System.out.println(s);
				}
				System.out.println("--------------");
				
				Iterator<String> iterator = col.iterator();
				while(iterator.hasNext()) {
					String str=iterator.next();
					System.out.println(str);
					
				}
	}

}
