package cg;
import java.util.*;
public class Collection1 {
	
	public static void main(String[] args) {
		Set col= new HashSet();
		
		col.add("Name1");
		
	    	col.add("Name2");
		
		col.add(33);	//autoboxing
		
		col.add(null);
		
		col.add("Name3");
		
		col.add("Name4");
		
		System.out.println(col.size());
	}
	
}
