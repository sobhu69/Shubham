package cg;

import java.util.*;

public class Collection3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Double> map = new HashMap<String,Double>();
		
		map.put("Name1", 5000.00);
		map.put("Name2", 7000.00);
		map.put("Name3", 9000.00);
		map.put("Name4", 4000.00);
		
		System.out.println(map);
		System.out.println(map.size());
		
		map.remove("Name1");
		System.out.println(map);
		System.out.println(map.size());
		
		Set<String> keysSet = map.keySet();
		System.out.println(keysSet);
		
		for(String k : keysSet) {
			Double val=map.get(k);
			System.out.println(k+" has balance of Rs."+val);
			
		}
		System.out.println("-------------------------------------");
		Double bal=map.get("Name2");
		System.out.println("Before balance "+bal);
		bal-=3000.00;//unboxing
		map.put("Name2", bal);
		bal=map.get("Name2");
		System.out.println("After balance "+bal);
		System.out.println("-------------------------------------");
		
		Collection<Double> vals = map.values();
		
		List<Double> vallist = new ArrayList<Double> (vals);
		
		Collections.sort(vallist);
		
		for(double d: vallist) {
			System.out.println(d);
			
		}
	}
	

}
