package com.capg.SpringBootDemo.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.SpringBootDemo.dao.EmployeeDAO;
import com.capg.SpringBootDemo.model.Employee;

@Service
public class EmployeeService {

	private EmployeeDAO employeeDAO;
	
	
	
	@Autowired
	public EmployeeService(EmployeeDAO employeeDAO) {
		super();
		this.employeeDAO = employeeDAO;
	}


	

	public List<Employee> getSortedEmpList(){
		List<Employee> empList=employeeDAO.findAll();
		return empList;
		
	}
	public Employee saveNewEmployee(Employee emp) {
		return employeeDAO.save(emp);
	}
	public boolean removeEmployee(int  emp) {
		return employeeDAO.deleteById(emp);
	}




	public Employee getEmp(int empId) {
		return employeeDAO.find(empId);
		
	}




	
	
	
}
