package com.capg.SpringBootDemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.capg.SpringBootDemo.model.Employee;

@Repository
@Transactional
public class EmployeeDAOImpl implements EmployeeDAO {

	private EntityManager entityManager;
	
	@Override
	public Employee find(int empId) {
		Employee emp=entityManager.find(Employee.class, empId);
		return null;
	}
	
	
	 
	 
	public EmployeeDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}




	@Override
	public List<Employee> findAll(){
		TypedQuery<Employee> query = entityManager.createQuery("SELECT e from Employee e",Employee.class);
				List<Employee> list=query.getResultList();
				return list;
	}

	@Override
	public boolean deleteById(int empId) {
		
		Employee emp=this.find(empId);
	
		if(emp!=null) {
		entityManager.remove(emp);
			return true;
		}
		else{
			return false;
		}
		
		
		}


	@Override
	public Employee save(Employee emp) {
		entityManager.persist(emp);
		return emp;
	}
	}
