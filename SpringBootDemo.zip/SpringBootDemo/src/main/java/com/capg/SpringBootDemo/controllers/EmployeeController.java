package com.capg.SpringBootDemo.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.SpringBootDemo.model.Employee;
import com.capg.SpringBootDemo.services.EmployeeService;

 

 

@RestController
public class EmployeeController {
  
  private EmployeeService empService;
  
  @Autowired
  public EmployeeController(EmployeeService empService) {
	  super();
	  this.empService=empService;
  }
  
  @GetMapping(value="/employees")
  public List<Employee> getEmployees(){
	  return empService.getSortedEmpList();
  }
  
  @PostMapping(value="/employees")
  public Employee createEmployee(@RequestBody Employee emp) {
  return empService.saveNewEmployee(emp);
  }
 
  @GetMapping("/employees/{empId}")
  public Employee getEmployee(@PathVariable int empId) {
	  return empService.getEmp(empId);
	  
  }
  
  @DeleteMapping("/employees/{empId}")
  public String removeEmployee(@PathVariable int empId) {
	  
	
	 

	  
		  	if(empService.removeEmployee(empId)) {
		  			return "Employee Deleted Successfully";
		  										}
		  	else {
		  			return "could not find the employee";
	  			}
	  				}
	  
  	}
