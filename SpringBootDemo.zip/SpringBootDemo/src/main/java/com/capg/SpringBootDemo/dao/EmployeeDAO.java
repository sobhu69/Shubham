package com.capg.SpringBootDemo.dao;

import java.util.List;

import com.capg.SpringBootDemo.model.Employee;

public interface EmployeeDAO {
	public Employee find(int empId);
	public List<Employee> findAll();
	boolean deleteById(int empId);
	public Employee save(Employee emp);

}
