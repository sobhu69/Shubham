import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  clickMessage = '';
  private printform:FormGroup;
  constructor() { }

  ngOnInit() {
    this.printform=new FormGroup({
      id: new FormControl(""),
      name: new FormControl(""),
      salary:new FormControl(""),
      department:new FormControl("")
    });
  }

  printEmp(){
    this.clickMessage = this.printform.value.id+' '+this.printform.value.name+' '+this.printform.value.salary+' '+this.printform.value.department;
 
    // alert(this.printform.value.id+' '+this.printform.value.name+' '+this.printform.value.salary+' '+this.printform.value.department)
  }
  

}
