import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  private updateform:FormGroup;
  constructor() { }

  ngOnInit() {
    this.updateform=new FormGroup({
      id: new FormControl(""),
      name: new FormControl(""),
      salary:new FormControl(""),
      department:new FormControl("")
    });
  }

  updateEmp(){
    
  }

}
