import { Component, OnInit } from '@angular/core';
import { data } from '../model/data.model';



@Component({
  selector: 'app-show-employee',
  templateUrl: './show-employee.component.html',
  styleUrls: ['./show-employee.component.css']
})
export class ShowEmployeeComponent implements OnInit {

  empData: Array<data>;
  msg='';
  constructor() { 
    this.empData=[
      {id:1001,name:"Rahul",salary:9000,department:"Java"},
      {id:1002,name:"Sachin",salary:20000,department:"OraApp"},
      {id:1003,name:"Rohan",salary:12000,department:"BI"}
    ];
  }

  ngOnInit() {
   
  }

  deletedata(add){
    let index = this.empData.indexOf(add);
        this.empData.splice(index,1);
        this.msg='DATA Deleted';

  }
  updatedata(add){

  }

}
