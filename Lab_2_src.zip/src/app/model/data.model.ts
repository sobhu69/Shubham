export class data {
     id:number;
     name:string;
     salary:number;
     department:string;

    constructor(id,name,salary,department){
        this.id= id;
        this.name = name;
        this.salary = salary;
        this.department = department;
    }

}
