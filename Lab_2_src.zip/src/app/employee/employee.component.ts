import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { data } from '../model/data.model';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  
  empData: Array<data>;

  clickMessage = '';
  private printform:FormGroup;
  constructor() { 
    
  }

  ngOnInit() {
    this.printform=new FormGroup({
      id: new FormControl(""),
      name: new FormControl(""),
      salary:new FormControl(""),
      department:new FormControl("")
    });
  }

  printEmp(id,name,salary,department){
        let add = new data(id,name,salary,department);
        this.empData.push(add);
        console.log(this.empData);
        //this.empData=this.myDist;
        
        


    // this.clickMessage = this.printform.value.id+' '+this.printform.value.name+' '+this.printform.value.salary+' '+this.printform.value.department;
 
    // alert(this.printform.value.id+' '+this.printform.value.name+' '+this.printform.value.salary+' '+this.printform.value.department)
  }
  

}
