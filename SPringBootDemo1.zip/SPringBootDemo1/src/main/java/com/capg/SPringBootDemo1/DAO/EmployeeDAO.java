package com.capg.SPringBootDemo1.DAO;

import java.util.List;

import com.capg.SPringBootDemo1.model.Employee;

public interface EmployeeDAO {
	
	public Employee find(int empId);
	public List<Employee> findAll();
	public Employee save(Employee emp);
	public boolean deletesById(int empId);

}
