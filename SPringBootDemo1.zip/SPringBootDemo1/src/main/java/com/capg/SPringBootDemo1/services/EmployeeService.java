package com.capg.SPringBootDemo1.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.SPringBootDemo1.DAO.EmployeeDAO;
import com.capg.SPringBootDemo1.model.Employee;

@Service
public class EmployeeService {
	
	private EmployeeDAO employeedao;
	
	@Autowired
	public EmployeeService(EmployeeDAO employeedao) {
		super();
		this.employeedao = employeedao;
	}



	public List<Employee> getSortedEmpList(){
		List<Employee>empList = employeedao.findAll();
		
		return empList;
		
	}
	
	public Employee saveNewEmployee(Employee emp) {
		return employeedao.save(emp);
	}
	
	
	public boolean removeEmployee(int empId) {
		return employeedao.deletesById(empId);
	}
	
	public Employee getEmp(int empId) {
		return employeedao.find(empId);
	}
}
