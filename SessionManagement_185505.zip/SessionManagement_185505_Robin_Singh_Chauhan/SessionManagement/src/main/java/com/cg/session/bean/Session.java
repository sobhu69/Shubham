package com.cg.session.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

/***
* Author : Robin Singh Chauhan
* Date of Creation : 30-July-2019
* Class Name : Session
* Purpose : Blueprint of SessionManagement Table
***/

@Entity
@Table(name = "SessionManagement")
public class Session {
	
	@Id
	@SequenceGenerator(name="sessId", sequenceName = "session_seq")
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="sessId")
	private int id;
	
	private String name;
	@Min(0)
	@Max(3)
	private int duration;
	private String faculty;
	@Column(name = "sessionMode")
	@Pattern(regexp = "(ILT|VC)")
	private String mode;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	
	@Override
	public String toString() {
		return "Session [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty + ", mode="
				+ mode + "]";
	}
	
}
