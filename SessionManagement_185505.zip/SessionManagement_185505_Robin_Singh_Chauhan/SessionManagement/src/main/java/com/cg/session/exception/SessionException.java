package com.cg.session.exception;

/***
* Author : Robin Singh Chauhan
* Date of Creation : 30-July-2019
* Class Name : SessionException
* Purpose : Exception Handling Class
***/

public class SessionException extends Exception{
	
	public SessionException() {
		super();
	}
	
	public SessionException(String msg) {
		super(msg);
	}

}


