package com.cg.session.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.SessionService;


/***
* Author : Robin Singh Chauhan
* Date of Creation : 30-July-2019
* Class Name : SessionController 
* Purpose : Main Controller class
*/
@RestController
public class SessionController {
	
	@Autowired
	SessionService sessionService;
	
	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : createSession
	* Parameters : Parameter of type Session object
	* Return Value : All session details
	* Purpose : To save the session details into the SESSIONMANAGEMENT table
	***/
	@RequestMapping(value="/createsession", method=RequestMethod.POST)
	public List<Session> createSession(@RequestBody Session sess) throws SessionException{
		return sessionService.createSession(sess);
	}
	
	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : updateSession
	* Parameters : Parameter of type Session object, id of type integer
	* Return Value : All session details
	* Purpose : To update session details into the SESSIONMANAGEMENT table
	***/
	@RequestMapping(value="/updatesession/{id}", method=RequestMethod.PUT)
	public List<Session> updateSession(@RequestBody Session sess, @PathVariable int id) throws SessionException{
		sessionService.updateSession(id, sess);
		return sessionService.getAllSession();
	}
	
	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : deleteSession
	* Parameters : Parameter of type integer
	* Return Value : All session details
	* Purpose : To delete session details from the SESSIONMANAGEMENT table
	***/
	@RequestMapping(value="/deletesession/{id}", method= RequestMethod.DELETE)
	public List<Session> deleteSession(@PathVariable int id) throws SessionException{
		sessionService.deleteSession(id);
		return sessionService.getAllSession();
	}
	
	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : getSession
	* Parameters : No parameters
	* Return Value : All session details
	* Purpose : To retrieve all session details from the SESSIONMANAGEMENT table
	***/
	@RequestMapping("/viewallsession")
	public List<Session> getSession() throws SessionException{
		return sessionService.getAllSession();
	}
	
	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : handleErrors
	* Parameters : Exception object
	* Return Value : Response Entity
	* Purpose : To handle any error in the execution
	***/
	@ExceptionHandler({SessionException.class})
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<String>("An Error occurred "+ex.getMessage(),HttpStatus.CONFLICT);
	}
	

}
