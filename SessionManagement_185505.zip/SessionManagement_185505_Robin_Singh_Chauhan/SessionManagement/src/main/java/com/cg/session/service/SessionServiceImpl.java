package com.cg.session.service;

/***
* Author : Robin Singh Chauhan
* Date of Creation : 30-July-2019
* Class Name : SessionServiceImpl
* Purpose : Implementation Class for SessionService interface
***/

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.session.bean.Session;
import com.cg.session.dao.SessionDao;
import com.cg.session.exception.SessionException;

@Service
public class SessionServiceImpl implements SessionService {
	
	@Autowired
	SessionDao sessionDao;

	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : createSession
	* Parameters : Parameter of type Session object
	* Return Value : All entries of SessionManagement table
	* Purpose : To create session details entry into the SESSIONMANAGEMENT table
	***/
	@Override
	public List<Session> createSession(Session sess) throws SessionException {
		try {
			sessionDao.save(sess);
			return sessionDao.findAll();
		} catch (Exception e) {
			throw new SessionException(", Error : Duration should be between 0 and 3 and Session name should be ILT or VC");
		}
	}

	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : updateSession
	* Parameters : Parameter of type integer, Session object
	* Return Value : All entries of SessionManagement table
	* Purpose : To update session details in the SESSIONMANAGEMENT table
	***/
	@Override
	public List<Session> updateSession(int id, Session sess) throws SessionException {
		try {
			Optional<Session> optional = sessionDao.findById(id);
			if(optional.isPresent()) {
				Session session = optional.get();
				session.setDuration(sess.getDuration());
				session.setFaculty(sess.getFaculty());
				sessionDao.save(session);
				return getAllSession();
			}
			else
				throw new SessionException(", Error : Session with ID " + id + " does not exist.");
		} catch (Exception e) {
			throw new SessionException(e.getMessage());
		}
	}

	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : deleteSession
	* Parameters : Parameter of type integer
	* Return Value : Void
	* Purpose : To delete session details by Id in the SESSIONMANAGEMENT table
	***/
	@Override
	public void deleteSession(int id) throws SessionException {
		try{
			sessionDao.deleteById(id);
		}
		catch(Exception e) {
			throw new SessionException(", Error : Session with ID " + id + " does not exist.");
		}
		
	}

	
	/***
	* Author : Robin Singh Chauhan
	* Date of Creation : 30-July-2019
	* Method Name : getAllSession
	* Parameters : None
	* Return Value : All entries of SessionManagement table
	* Purpose : To retrieve all session details from the SESSIONMANAGEMENT table
	***/
	@Override
	public List<Session> getAllSession() throws SessionException {
		try {
			return sessionDao.findAll();
		} catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
	}
	
	

}
