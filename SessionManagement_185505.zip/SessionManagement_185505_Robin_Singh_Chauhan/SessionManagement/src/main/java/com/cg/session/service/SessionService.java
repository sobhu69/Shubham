package com.cg.session.service;
import java.util.List;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;

/***
* Author : Robin Singh Chauhan
* Date of Creation : 30-July-2019
* Interface Name : SessionService
* Purpose : Signature of all required Service methods
***/

public interface SessionService {
	
	public List<Session> createSession(Session sess) throws SessionException;
	
	public List<Session> updateSession(int id, Session sess) throws SessionException;
	
	public void deleteSession(int id) throws SessionException;
	
	public List<Session> getAllSession() throws SessionException;
	
}
