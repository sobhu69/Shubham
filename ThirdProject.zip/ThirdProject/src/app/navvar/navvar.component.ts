import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navvar',
  templateUrl: './navvar.component.html',
  styleUrls: ['./navvar.component.css']
})
export class NavvarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
