import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent implements OnInit {

  private registerform:FormGroup;

  constructor() { }

  ngOnInit() {
    this.registerform=new FormGroup({
      username: new FormControl("",[Validators.required,Validators.minLength(4),this.shouldNotContainSpace]),
      password:new FormControl(""),
      email:new FormControl("")
    });
  }

  shouldNotContainSpace(control:AbstractControl):ValidationErrors | null{
      const value=control.value;
      if(value.indexOf(' ') != -1){
          return{shouldNotContainSpace:true}
      }
    return null;
  }

  register(){
    console.log(this.registerform)
  }
  

}
