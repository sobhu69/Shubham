import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  myvalue:number

  isActive:Boolean
  bordered={border: '1px solid brown',
   background:'bisque',
   padding:'1px'}

  constructor() { }

  ngOnInit() {
    this.isActive=true;
    this.myvalue=2;
  }

  handleClick(){
    this.isActive  =this.isActive?false:true;
  }
}
