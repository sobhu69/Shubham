import { Directive, ElementRef, Renderer2, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlights]'
})
export class HighlightsDirective {

  @HostBinding('style.backgroundColor')
  private bgColor:String = 'pink'

  // constructor(private eleRef:ElementRef, private renderer:Renderer2) { 
  //   // console.log('Highlight Directive is applied', this.eleRef.nativeElement)
  //   // this.eleRef.nativeElement.style.background = 'yellowgreen'
  //   //this.renderer.setStyle(this.eleRef.nativeElement,'background','orange')

  // }
  @HostListener('mouseover')
  changeColorMouseOver(){
    this.bgColor='orange'
  }
  @HostListener('mouseout')
  changeColorMouseOut(){
    this.bgColor='pink'
  }

}
