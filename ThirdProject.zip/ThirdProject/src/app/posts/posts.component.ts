import { Component, OnInit } from '@angular/core';
import { post } from '../model/post.model';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  private postsData:post[] = [];

  constructor(private http:HttpClient, private router:Router) { }

  ngOnInit() {
    this.http.get<post[]>('https://jsonplaceholder.typicode.com/posts')
              .subscribe(
                (response:post[])=>{
                  console.log('response recieved from server....')
                  console.log(response)
                  this.postsData=response;
                },
                (error)=>{
                  console.log('error from server...')
                  console.log(error)
                }
              )
  }

  addnewPost(){
    this.router.navigate(['post-form'])
  }


}
