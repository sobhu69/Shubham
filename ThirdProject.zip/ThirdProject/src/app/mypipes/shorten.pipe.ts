import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'shorten'
})
export class ShortenPipe implements PipeTransform {

  transform(value:string, length:number=100): string {
    if(length){
      if(value.length<=length)
      return value;

      return value.substring(0,length)+'...'
    }
    
  }

}
