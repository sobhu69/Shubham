import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';
import { HttpClient } from '../../../node_modules/@angular/common/http';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  private employeeform:FormGroup;
  private empData:any[] = [];
  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.employeeform=new FormGroup({
     
      firstName:new FormControl(""),
      lastName:new FormControl(""),
      city:new FormControl(""),
      salary:new FormControl("")
    });
  }
  addemp(){
    this.http.post<any[]>('http://localhost:8084/employees',this.employeeform.value)
    .subscribe(
      (response:any[])=>{
        console.log('response recieved from server....')
        console.log(response)
        this.empData=response;
      },
      (error)=>{
        console.log('error from server...')
        console.log(error)
      }
    )
    
  }

  
}
