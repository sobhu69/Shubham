package com.cg.productcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartManagementApplication {
	
	/*
	 * Author: Chandan Tiwari 
	 * Date of Creation: 30/07/19
	 * Method Name: main
	 * Parameters: String[] args
	 * return value: void
	 * purpose: main method to run the application
	 */

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementApplication.class, args);
	}

}
