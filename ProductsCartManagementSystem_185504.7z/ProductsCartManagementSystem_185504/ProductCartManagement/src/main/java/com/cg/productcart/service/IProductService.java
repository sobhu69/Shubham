package com.cg.productcart.service;

import java.util.List;

import com.cg.productcart.bean.Product;
import com.cg.productcart.exception.ProductException;


public interface IProductService {
	
	public List<Product> createProduct(Product product) throws ProductException;
	
	public Product findProductById(String id) throws ProductException;
	
	public List<Product> deleteProduct(String id) throws ProductException;
	
	public List<Product> ViewProducts() throws ProductException;
	
	public List<Product> updateProduct(String id, Product product) throws ProductException;

}
