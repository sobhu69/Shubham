package com.cg.productcart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productcart.bean.Product;
import com.cg.productcart.exception.ProductException;
import com.cg.productcart.service.IProductService;

@RestController
public class ProductController {
	
	@Autowired
	IProductService productService;
	
	/*
	 * Author: Chandan Tiwari 
	 * Date of Creation: 30/07/19
	 * Method Name: viewAllProducts
	 * Parameters: void
	 * return value: List<Product>
	 * purpose: Controller for display all the records
	 */
	@RequestMapping("/products")
	public List<Product> viewAllProducts() throws ProductException{
		return productService.ViewProducts();
	}
	
	/*
	 * Author: Chandan Tiwari 
	 * Date of Creation: 30/07/19
	 * Method Name: addProduct
	 * Parameters: Product product
	 * return value: List<Product>
	 * purpose: create and add the product to the table
	 */
	@RequestMapping(value="/products", method=RequestMethod.POST)
	public List<Product> addProduct(@RequestBody Product product) throws ProductException{
		return productService.createProduct(product);
	}
	
	/*
	 * Author: Chandan Tiwari 
	 * Date of Creation: 30/07/19
	 * Method Name: updateProduct
	 * Parameters: String id, Product product
	 * return value: List<Product>
	 * purpose: update the Product price which is enter into the url
	 */
	@RequestMapping(value="/products/{id}", method=RequestMethod.PUT)
	public List<Product> updateProduct(@PathVariable String id, @RequestBody Product product) throws ProductException{
		return productService.updateProduct(id, product);
	}
	
	/*
	 * Author: Chandan Tiwari 
	 * Date of Creation: 30/07/19
	 * Method Name: deleteProduct
	 * Parameters: String id
	 * return value: List<Product>
	 * purpose: delete a product provided in url
	 */
	@RequestMapping(value="/products/{id}", method=RequestMethod.DELETE)
	public List<Product>  deleteProduct(@PathVariable String id) throws ProductException {
		return productService.deleteProduct(id);
	}
	
	/*
	 * Author: Chandan Tiwari 
	 * Date of Creation: 30/07/19
	 * Method Name: findProduct
	 * Parameters: String id
	 * return value: Product
	 * purpose: find and return a product which id is provided in url
	 */
	@RequestMapping(value="/products/{id}", method=RequestMethod.GET)
	public Product findProduct(@PathVariable String id) throws ProductException {
		return productService.findProductById(id);
	}

}
