package com.cg.productcart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productcart.bean.Product;
import com.cg.productcart.dao.IProductRepo;
import com.cg.productcart.exception.ProductException;

@Service
public class ProductServiceImpl implements IProductService{
	
	@Autowired
	IProductRepo productRepo;

	@Override
	public List<Product> createProduct(Product product) throws ProductException {
		try {
			productRepo.save(product);
			return productRepo.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public Product findProductById(String id) throws ProductException {
		try {
			return productRepo.findById(id).get();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> deleteProduct(String id) throws ProductException {
		try {
			productRepo.deleteById(id);
			return ViewProducts();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		
	}

	@Override
	public List<Product> ViewProducts() throws ProductException {
		try {
			return productRepo.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> updateProduct(String id, Product product) throws ProductException {
		try {
			Optional<Product> optional = productRepo.findById(id);
			if(optional.isPresent()) {
				Product prod = optional.get();
				prod.setName(product.getName());
				prod.setModel(product.getModel());
				prod.setPrice(product.getPrice());
				productRepo.save(prod);
				return ViewProducts();
			}
			else
				throw new ProductException("Customer with ID " + id + " does not exist.");
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

}
