package com.cg.productcart.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.productcart.exception.ProductException;

@ControllerAdvice
public class ProductExceptionHandler {
	
	/*
	 * Author: Chandan Tiwari 
	 * Date of Creation: 30/07/19
	 * Method Name: handleException
	 * Parameters: Exception ex
	 * return value: ResponseEntity<String>
	 * purpose: method for handling execptions
	 */
	@ExceptionHandler({ProductException.class})
	public ResponseEntity<String> handleException(Exception ex){
		return new ResponseEntity<String>("Error: " + ex.getMessage(), HttpStatus.CONFLICT);
	}

}
