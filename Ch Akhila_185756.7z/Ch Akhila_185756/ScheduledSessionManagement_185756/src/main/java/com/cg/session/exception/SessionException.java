package com.cg.session.exception;

public class SessionException extends Exception{

		public SessionException() {
			super();
			
		}
		public SessionException(String msg) {
			super(msg);
			
		}
		

	}



