package com.cg.session.service;

import java.util.List;



import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;

public interface SessionServiceInterface {
	List<Session> createSession(Session session) throws SessionException;

	List<Session> deleteSession(Integer id) throws SessionException;

	List<Session> updateSession(Session session) throws SessionException;

	List<Session> viewAllSession();

}
