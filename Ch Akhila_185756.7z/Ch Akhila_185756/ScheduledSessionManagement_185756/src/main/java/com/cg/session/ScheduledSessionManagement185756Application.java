package com.cg.session;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheduledSessionManagement185756Application {

	public static void main(String[] args) {
		SpringApplication.run(ScheduledSessionManagement185756Application.class, args);
	}

}
