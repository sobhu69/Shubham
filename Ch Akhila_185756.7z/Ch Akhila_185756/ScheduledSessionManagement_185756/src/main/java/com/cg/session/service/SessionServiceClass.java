package com.cg.session.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.session.bean.Session;
import com.cg.session.dao.SessionDaoInterface;
import com.cg.session.exception.SessionException;
@Service
public class SessionServiceClass implements SessionServiceInterface {
	@Autowired
	SessionDaoInterface sessionDao;

	@Override
	public List<Session> createSession(Session session) throws SessionException {
		// TODO Auto-generated method stub
		try {

			{
				sessionDao.save(session);
				return sessionDao.findAll();
			}

		} catch (Exception e) {
			throw new SessionException("Duration should be between 0 and 3 and mode of session should be either ILT or VC");
		}
		
	}

	@Override
	public List<Session> viewAllSession() {
		// TODO Auto-generated method stub
		return sessionDao.findAll();
	}

	@Override
	public List<Session> deleteSession(Integer id) throws SessionException {
		// TODO Auto-generated method stub
		try{
		sessionDao.deleteById(id);
		return viewAllSession();
		}
		 catch (Exception e) {
				throw new SessionException(" "+id+" doesn't exist");
			}
	}

	@Override
	public List<Session> updateSession(Session session) throws SessionException {
		// TODO Auto-generated method stub
		try {
			Optional<Session> optional = sessionDao.findById(session.getId());
			if (optional.isPresent()) {
				Session session1 = optional.get();
				session1.setFaculty(session.getFaculty());
				session1.setDuration(session.getDuration());
				sessionDao.save(session1);
				return viewAllSession();

			} else {
				throw new SessionException("Given Invalid details!!");
			}

		} catch (Exception e) {
			throw new SessionException("Given Invalid details!!");

		}
	
		
		
		
		
		
		
	}

}
