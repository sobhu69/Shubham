package com.cg.session.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.SessionServiceInterface;

@RestController
public class SessionController
{
	@Autowired
	SessionServiceInterface service;
	/***
	 * Author:Ch Akhila
	 * Date of Creation:30-07-2019
	 * Method Name:createSession
	 * Parameters:Requestbody from postman
	 * return value:Newly created Session
	 * purpose:To create new Session according to the requirement
	 */
	@RequestMapping(value = "/createSession", method = RequestMethod.POST)
	public List<Session> createSession(@RequestBody Session session) throws SessionException  {
		return  service.createSession(session);
	}
	/***
	 * Author:Ch Akhila
	 * Date of Creation:30-07-2019
	 * Method Name:viewAllSession
	 * Parameters:No Parameters
	 * return value:List of sessions 
	 * purpose:To view all Sessions
	 */
	@RequestMapping(value = "/viewAllSessions", method = RequestMethod.GET)
	public List<Session> viewAllSession() {
		return  service.viewAllSession();
	}
	/***
	 * Author:Ch Akhila
	 * Date of Creation:30-07-2019
	 * Method Name:updateSession
	 * Parameters:id
	 * return value:List of sessions with Updated one
	 * purpose:To update the session data of given id
	 */
	@RequestMapping(value = "/updateSession/{id}", method = RequestMethod.PUT)
	public List<Session> updateSession(@RequestBody Session session) throws SessionException {
		return  service.updateSession(session);
	}
	/***
	 * Author:Ch Akhila
	 * Date of Creation:30-07-2019
	 * Method Name:deleteSession
	 * Parameters:id
	 * return value:List of sessions with Deleted one
	 * purpose:To delete session data of given id
	 * @throws SessionException 
	 */
	
	@RequestMapping(value = "/deleteSession/{sid}", method = RequestMethod.DELETE)
	public List<Session> deleteSession(@PathVariable("sid") Integer id) throws SessionException {
		return  service.deleteSession(id);
		
		
	}

}
