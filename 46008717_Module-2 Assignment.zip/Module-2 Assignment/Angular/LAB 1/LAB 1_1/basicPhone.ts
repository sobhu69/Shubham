import{Mobile} from './mobile';


export class Basicphone extends Mobile{
  mobiletype:string;
  constructor(mobilebp)
  {
    super(101,"Nokia",2000);
    this.mobiletype=mobilebp;

  }
  printMobileDetails()
  {
      super.printMobileDetails();
      console.log("Mobile Type of basic phone :"+this.mobiletype);
  }
}