import {Smartphone} from './smartPhone';
import {Basicphone} from './basicPhone';
var arry = new Array();
var bphn = new Basicphone("Keypad");
arry.push(bphn);

var sphn = new Smartphone("Without keypad");
arry.push(sphn);

for(var i=0;i<arry.length;i++)
{
    arry[i].printMobileDetails();
}

