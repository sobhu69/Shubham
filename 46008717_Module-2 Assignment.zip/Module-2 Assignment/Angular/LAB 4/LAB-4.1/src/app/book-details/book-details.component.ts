import { Component, OnInit } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';


@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {
  private bookData:any[] = [];
  constructor(private http:HttpClient) { 

  }

  ngOnInit() {
    this.http.get<any>('./assets/booklist.json')
    .subscribe((response)=>{console.log('')
    this.bookData=response;
    },
    (error)=>{
      console.log('error from server...')
      console.log(error)
      }
   )
  }

}
