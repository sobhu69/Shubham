package com.capg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MovieCategory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int mcatId;
	private String mcatName;
	
	public MovieCategory() {
		super();
	}

	public MovieCategory(String mcatName) {
		super();
		this.mcatName = mcatName;
	}

	public int getMcatId() {
		return mcatId;
	}

	public void setMcatId(int mcatId) {
		this.mcatId = mcatId;
	}

	public String getMcatName() {
		return mcatName;
	}

	public void setMcatName(String mcatName) {
		this.mcatName = mcatName;
	}

	@Override
	public String toString() {
		return "MovieCategory [mcatId=" + mcatId + ", mcatName=" + mcatName + "]";
	}
	
	

}
