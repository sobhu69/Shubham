package com.capg;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
