package com.cg.productapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.productapp.exception.ProductException;
/***
 *Author:Y.Srilekha
 *Date of Creation:30/7/2019
 *ClassName:UniversalExceptionHandler
 *parameters:product parameters
 *return value:Respose Entity
 *purpose:Exception Handling
 */
@ControllerAdvice
public class ProductExceptionHandler {
	@ExceptionHandler(ProductException.class)
	public ResponseEntity<String> handleException(Exception e){
		return new ResponseEntity<String>("Error :"+e.getMessage(),HttpStatus.CONFLICT);
	}
}

