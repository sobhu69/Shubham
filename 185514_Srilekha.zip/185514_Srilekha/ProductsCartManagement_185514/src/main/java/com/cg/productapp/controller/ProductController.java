package com.cg.productapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productapp.bean.Product;
import com.cg.productapp.exception.ProductException;
import com.cg.productapp.service.IProductService;

/***
 * Author:Y.Srilekha
 * Date of Creation:30/7/2019
 * ClassName:ControllerClass
 * parameters:Add,Delete,Update,Find by Id,Getproduct list
 * return value:null
 * purpose:creation of Controller
 */

@RestController
public class ProductController {
	@Autowired
	IProductService productService;

	//Get Products list
	@RequestMapping("/products")
	public List<Product> getProducts() throws ProductException {
		return productService.getAllProducts();
	}

	//Finding products by Id
	@RequestMapping("products/{id}")
	public Product findProductsById(@PathVariable String id) throws ProductException {
		return productService.getProductById(id);
	}

	// Adding products to List
	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public ResponseEntity<String> addProduct(@RequestBody Product pro) throws ProductException {
		productService.addProduct(pro);
		return new ResponseEntity<String>("Product is added successfully", HttpStatus.OK);
	}

	// Deleting a product data from the database
	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteProduct(@PathVariable String id) throws ProductException {
		productService.deleteProduct(id);
		return new ResponseEntity<String>("Product with id " + id + "deleted", HttpStatus.OK);
	}

	// Updating the Existing Data
	@RequestMapping(value = "/products/{id}", method = RequestMethod.PUT)
	public ResponseEntity<String> updateProduct(@RequestBody Product pro) throws ProductException {
		productService.updateProduct(pro);
		return new ResponseEntity<String>("Product is updated successfully", HttpStatus.OK);
	}

}
