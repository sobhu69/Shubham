package com.cg.productapp.service;

import java.util.List;

import com.cg.productapp.bean.Product;
import com.cg.productapp.exception.ProductException;

/***
 *Author:Y.Srilekha
 *Date of Creation:30/7/2019
 *InterfaceName:IproductService
 *parameters:product parameters
 *return value:null
 *purpose:Service Interface
 */ 


public interface IProductService {
	public List<Product> getAllProducts() throws ProductException;

	public Product getProductById(String id) throws ProductException;

	public List<Product> addProduct(Product pro) throws ProductException;

	public List<Product> deleteProduct(String id) throws ProductException;

	public List<Product> updateProduct(Product pro) throws ProductException;
}
