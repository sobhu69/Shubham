package com.cg.productapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productapp.bean.Product;
import com.cg.productapp.dao.IProductRepo;
import com.cg.productapp.exception.ProductException;

/***
 *  Author:Y.Srilekha
 *  Date of Creation:30/7/2019
 *  ClassName:ProductServiceImpl
 *  parameters:product parameters
 *  purpose:Service Implementation
 */


@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductRepo productDao;

	//Get All Products
	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	//Add products
	@Override
	public List<Product> addProduct(Product pro) throws ProductException {
		try {// TODO Auto-generated method stub
			productDao.save(pro);
			return productDao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	//UpdateProducts
	@Override
	public List<Product> updateProduct(Product pro) throws ProductException {
		// TODO Auto-generated method stub
		try {
			productDao.save(pro);
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		return null;
	}

	//Get product by id 
	@Override
	public Product getProductById(String id) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.findById(id).get();
	}

	//Delete the product by Id
	@Override
	public List<Product> deleteProduct(String id) throws ProductException {
		// TODO Auto-generated method stub
		try {
			productDao.deleteById(id);
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		return null;
	}
}
