package com.cg.productapp.exception;
//Product Exception
public class ProductException extends Exception {
	public ProductException() {
		super();
	}

	public ProductException(String msg) {
		super(msg);
	}
}
