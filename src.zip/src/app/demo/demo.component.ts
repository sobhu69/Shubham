import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../myservices/employee.service';
import { HttpClient } from '../../../node_modules/@types/selenium-webdriver/http';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  myvalue:number

  isActive:Boolean
  bordered={border: '1px solid brown',
   background:'bisque',
   padding:'1px'}

  constructor() { }
  // constructor(private empService:EmployeeService,private http:HttpClient){}
  ngOnInit() {
    this.isActive=true;
    this.myvalue=2;

    // this.http.get('./assets/json  file name')
    // .subscribe((response)=>{console.log('')})
  }

  handleClick(){
    this.isActive  =this.isActive?false:true;
    
  }
}
