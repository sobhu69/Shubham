import { Component, OnInit } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';
import { post } from '../model/post.model';

@Component({
  selector: 'app-post-form',
  templateUrl: './post-form.component.html',
  styleUrls: ['./post-form.component.css']
})
export class PostFormComponent implements OnInit {
  private postform:FormGroup;
  private postsData:post[] = [];
  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.postform=new FormGroup({
      postTitle: new FormControl(""),
      body:new FormControl(""),
      userId:new FormControl("")
    });
  }

  addPost(){
    console.log('form data....')
    //console.log(this.postform.value.userId)
    this.http.post<post[]>('https://jsonplaceholder.typicode.com/posts',this.postform.value)
    .subscribe(
      (response:post[])=>{
        console.log('response recieved from server....')
        console.log(response)
        this.postsData=response;
      },
      (error)=>{
        console.log('error from server...')
        console.log(error)
      }
    )
  }

}
