import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private empData:any[];
  constructor() { }

  public getAllEmployee(){
    return this.empData;
  }

  public addNewEmployee(emp){
    this.empData.push(emp)
  }

  public getEmployee(empId){

  }

  public updateEmployee(updateEmp){

  }

  public deleteEmp(empId){
    
  }
}
