import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(courses:any[],category:string="BEGINNER"): any {
    return courses.filter((c) =>c.category===category);
  }

}
