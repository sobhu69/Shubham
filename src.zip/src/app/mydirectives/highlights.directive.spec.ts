import { HighlightsDirective } from './highlights.directive';

describe('HighlightsDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightsDirective();
    expect(directive).toBeTruthy();
  });
});
