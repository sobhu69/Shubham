import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { DemoComponent } from './demo/demo.component';
import { HighlightsDirective } from './mydirectives/highlights.directive';
import { CoursesComponent } from './courses/courses.component';
import { ShortenPipe } from './mypipes/shorten.pipe';
import { FilterPipe } from './mypipes/filter.pipe';
import { HomeComponent } from './home/home.component';
import { NavvarComponent } from './navvar/navvar.component';
import { Routes,RouterModule } from '@angular/router';
import { PostsComponent } from './posts/posts.component';
import { HttpClientModule } from '@angular/common/http';
import { PostFormComponent } from './post-form/post-form.component';

const appRoutes:Routes =[
  {path: '', component:HomeComponent},
  {path: 'courses', component: CoursesComponent},
  {path: 'login', component: LoginComponent },
  {path: 'register', component: RegisterFormComponent },
  {path: 'posts', component: PostsComponent },
  {path: 'post-form', component: PostFormComponent }

]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterFormComponent,
    DemoComponent,
    HighlightsDirective,
    CoursesComponent,
    ShortenPipe,
    FilterPipe,
    HomeComponent,
    NavvarComponent,
    PostsComponent,
    PostFormComponent
  ],
  imports: [
    
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
