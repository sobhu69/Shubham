export class post {
    private userId:number;
    private id:number;
    private title:string;
    private body:string;
}