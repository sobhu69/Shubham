import { Component, OnInit } from '@angular/core';
import { post } from '../model/post.model';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  private postsData:post[] = [];

  constructor(private http:HttpClient, private router:Router) { }

  ngOnInit() {
    this.http.get<post[]>('https://jsonplaceholder.typicode.com/posts')
              .subscribe(
                (response:post[])=>{
                  console.log('response recieved from server....')
                  console.log(response)
                  this.postsData=response;
                },
                (error)=>{
                  console.log('error from server...')
                  console.log(error)
                }
              )
  }

  addnewPost(){
    this.router.navigate(['post-form'])
  }

  deletepost(post){
    this.http.delete<post>('https://jsonplaceholder.typicode.com/posts'+'/'+post.id)
      .subscribe(
        (response)=>{
          const index = this.postsData.indexOf(post)
          this.postsData.splice(index,1)
          console.log('delete response recieved from server....')
          
        },
        (error)=>{
          console.log('error from server...')
          console.log(error)
        }
      )

  }

  updatepost(post){
    post.title = 'It is new title..'
    this.http.patch<post>('https://jsonplaceholder.typicode.com/posts'+'/'+post.id,post)
      .subscribe(
        (response)=>{
          const index = this.postsData.indexOf(post)
          this.postsData[index] = response
          console.log('response recieved from server....')
          
        },
        (error)=>{
          console.log('error from server...')
          console.log(error)
        }
      )

  }


}
